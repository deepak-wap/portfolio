import Head from 'next/head'
import Home from '@/components/homepage'

export default Home