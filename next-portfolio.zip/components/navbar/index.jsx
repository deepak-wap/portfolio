import Head from "next/head";
import Image from "next/image";
import "@/styles/Navbar.module.css";
import { useState,  useEffect} from "react";
import { Button, Layout, Menu } from "antd";

const { Header } = Layout;
const items = [
  {
    key: "home",
    label: "HOME",
  },
  {
    key: "about-me",
    label: "ABOUT ME",
  },
  {
    key: "projects",
    label: "PROJECTS",
  },
  {
    key: "services",
    label: "SERVICES",
  },
  {
    key: "contact",
    label: "CONTACT",
  },
];
const Navbar = ()=>{
const [scrollHeight, setScrollHeight] = useState(0);

useEffect(()=>{
  const handleScroll = ()=>{
    const currentScrollHeight =
      typeof window !== "undefined"
        ? window.pageYOffset || document.documentElement.scrollTop
        : 0;
        console.log(currentScrollHeight);
    setScrollHeight(currentScrollHeight);
  };

  if (typeof window !== "undefined") {
    window.addEventListener("scroll", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }
}, []);

  return (
    <>
      <Header className={`flex justify-between items-center px-[8.7%] h-[95px] bg-[#05192E]`}> {/*bg-[#040B17] */}
        {/* <Image src={"/images/logo-light.svg"} width={156} height={35} /> */}
        {/* <h1 className="text-[38px] text-white left-[154px] absolute font-grotesk font-bold mt-[60px]">DEEPAK</h1> */}
        <h1 className="text-[38px] text-white font-grotesk font-bold">
          DEEPAK
        </h1>
        <div className="flex items-center gap-14">
          <Menu
            mode="horizontal"
            defaultSelectedKeys={'home'}
            items={items}
            style={{
              flex: 1,
              minWidth: 500,
            }}
            className="gap-1 text-[14.7px] text-[#ece9e9] font-grotesk font-semibold tracking-[0.8px] bg-[#05192E]"
          />
          <div className="nav-btn">
          <Button type="primary w-[145px] h-[56px] rounded-[30px] bg-[#0788FC] font-normal">
            <span className="text-[15.5px] font-grotesk tracking-[0.3px]">
              LETS' TALK
            </span>
          </Button>
          </div>
        </div>
      </Header>
      {/* <div className="w-full py-7 bg-[#05192E]"></div> */}
      {/* <header className="w-full absolute px-[8.5%] py-8 z-[-5] bg-[#040B17] mt-2">
                <nav>
                    <div className="flex items-center justify-between">
                        <Image src={'/images/logo-light.svg'} width={156} height={35}/>
                        <div className="flex">
                            <ul className="flex gap-10">
                                <li className="text-white">HOME</li>
                                <li className="text-white">ABOUT ME</li>
                                <li className="text-white">PROJECTS</li>
                                <li className="text-white">SERVICES</li>
                                <li className="text-white">CONTACT</li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </header> */}
    </>
  );
};

export default Navbar;
