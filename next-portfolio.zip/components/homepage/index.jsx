import Head from "next/head";
import Image from "next/image";
import React, { useRef, useState } from "react";
import "@/styles/Home.module.css";
import Navbar from "../navbar";
import "font-awesome/css/font-awesome.min.css";
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/navigation";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination, Navigation } from "swiper/modules";
import { Button, Layout, Card } from "antd";
const { Header } = Layout;
const Homepage = () => {
  return (
    <>
      <Head>
        <title>Homepage</title>
      </Head>
      <Navbar />
      {/* Homepage */}
      <div className="grid grid-cols-2 px-[8.5%] bg-[#05192E] home" id="home">
        <div className="flex flex-col justify-center">
          <Button
            type="primary"
            className="items-center bg-[#063661] w-fit h-[30px] p-0 px-3 mt-5 mb-1 rounded-[4px]"
          >
            <h1 className="text-[16px] text-white font-grotesk tracking-[3px]">
              DEEPAK
            </h1>
          </Button>
          <h2 className="text-[70px] text-white font-grotesk font-bold leading-snug">
            HAY! I'M DEEPAK
          </h2>
          <h2 className="text-[48px] text-[#0788FF] font-grotesk font-bold leading-snug">
            FULL STACK DEVELOPER
          </h2>
          <p className="text-[20px] text-white font-grotesk mt-5 mb-6">
            Yet bed any for travelling assistance indulgence unpleasing. Not
            thoughts all exercise blessing. Indulgence way everything joy
            alteration boisterous the attachment.
          </p>
          <div className="flex items-center gap-6 common-btn">
            <Button type="primary w-[192px] h-[56px] rounded-[30px] bg-[#0788FC] font-medium">
              <span className="text-[15.5px] font-grotesk tracking-[0.3px]">
                GET IN TOUCH
                <i class="fa fa-long-arrow-right text-[16px] text-white ml-2"></i>
              </span>
            </Button>
            <div className="flex gap-[9px]">
              <div className="hover:mt-[-2px] w-[46px] h-[46px] bg-[#1877F2] rounded-[50%] border-2 border-white flex justify-center items-center">
                <a href="/" className="text-[20px]">
                  <i className="fa fa-facebook text-white font-grotesk font-bold" />
                </a>
              </div>
              <div className="hover:mt-[-2px] w-[46px] h-[46px] bg-[#F26798] rounded-[50%] border-2 border-white flex justify-center items-center">
                <a href="/" className="text-[20px]">
                  <i className="fa fa-dribbble text-white font-grotesk font-bold" />
                </a>
              </div>
              <div className="hover:mt-[-2px] w-[46px] h-[46px] bg-[#1877F2] rounded-[50%] border-2 border-white flex justify-center items-center">
                <a href="/" className="text-[20px]">
                  <i className="fa fa-linkedin text-white font-grotesk font-bold" />
                </a>
              </div>
            </div>
          </div>
        </div>
        <div className="ml-3 pt-14">
          <Image src={"/images/home-banner.png"} width={546} height={581} />
        </div>
      </div>
      <div className="w-full flex items-center bg-[#07233B] px-[8.6%] py-10">
        <Swiper
          slidesPerView={5}
          spaceBetween={40}
          autoplay={{
            delay: 2500,
          }}
          pagination={{
            clickable: true,
          }}
          modules={[Autoplay, Pagination, Navigation]}
        >
          <SwiperSlide>
            <Image src={"/images/brand-1.svg"} width={172} height={40} />
          </SwiperSlide>
          <SwiperSlide>
            <Image src={"/images/brand-2.svg"} width={172} height={40} />
          </SwiperSlide>
          <SwiperSlide>
            <Image src={"/images/brand-1.svg"} width={172} height={40} />
          </SwiperSlide>
          <SwiperSlide>
            <Image src={"/images/brand-2.svg"} width={172} height={40} />
          </SwiperSlide>
          <SwiperSlide>
            <Image src={"/images/brand-1.svg"} width={172} height={40} />
          </SwiperSlide>
        </Swiper>
      </div>

      {/* About */}
      <div className="grid grid-cols-2 px-[8.5%] pb-10 bg-[#05192E]" id="about">
        <div className="pl-24 pt-[122px] relative">
          <Image
            src="/images/about-banner.png"
            width={450}
            height={551}
            alt="about-banner"
            className="relative z-[1]"
          />
          <Image 
                src="/images/effect-1.svg"  
                width={339} 
                height={339}
                alt="effect-1"
                className="absolute left-[-10px] bottom-[2px]"
            />
        </div>
        <div className="pl-12 pt-[60px] pb-[70px]">
            <Button
              type="primary"
              className="items-center bg-[#063661] w-fit h-[26px] p-0 px-3 mt-5 mb-2 rounded-[4px]"
            >
              <h1 className="text-[15px] text-white font-grotesk tracking-[3px]">
                ABOUT US
              </h1>
            </Button>
            <div className="w-[585px] flex justify-between items-start mb-6">
                <h2 className="text-[40px] text-white font-grotesk font-bold leading-[48px]">
                    <p>I AM AVAILABLE FOR</p>
                    <p className="text-[#0788FF]">UI UX DESIGN</p>
                    <p>PROJECTS</p>
                </h2>
                <Image 
                    src="/images/effect-1.svg"  
                    width={151} 
                    height={151}
                    alt="effect-1"
                />
            </div>
            <p className="text-[16px] text-white font-grotesk w-[380px] leading-[25px] mb-8">
              The standard chunk of Lorem Ipsum used since the 1500s is
              reproduced below for those interested. Sections 1.10.32 and
              1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also
              reproduced in their exact original form, accompanied by English
              versions from the 1914 translation by H. Rackham.
            </p>
            <div className="flex gap-2 mb-10">
              <div className="w-[110px] h-[115px] bg-[#111f2c67] rounded-[8px] border boder-[1px] border-slate-500 px-5 py-3">
                <h3 className="text-[27px] text-white font-grotesk font-medium">
                  280+
                </h3>
                <p className="text-[13px] text-white font-grotesk">
                  Google Review
                </p>
              </div>
              <div className="w-[125px] h-[115px] bg-[#111f2c67] rounded-[8px] border boder-[1px] border-slate-500 px-5 py-3">
                <p className="text-[27px] text-white font-grotesk font-medium">
                  15+
                </p>
                <p className="text-[13px] text-white font-grotesk">
                  Years Experience
                </p>
              </div>
              <div className="w-[125px] h-[115px] bg-[#111f2c67] rounded-[8px] border boder-[1px] border-slate-500 px-5 py-3">
                <p className="text-[27px] text-white font-grotesk font-medium">
                  49+
                </p>
                <p className="text-[13px] text-white font-grotesk">
                  Award Winning
                </p>
              </div>
            </div>
            <div className="common-btn">
            <Button type="primary w-[192px] h-[56px] rounded-[30px] bg-[#0788FC] font-medium">
              <span className="text-[15.5px] font-grotesk tracking-[0.3px]">
                GET IN TOUCH
                <i class="fa fa-long-arrow-right text-[16px] text-white ml-2"></i>
              </span>
            </Button>
            </div>
        </div>
      </div>

      {/* RECENT PROJECT */}
      <div className="grid grid-cols-1 px-[8.6%] pt-20 pb-20 bg-[#07233B]">
            <Button
                type="primary"
                className="items-center bg-[#063661] w-fit h-[29px] p-0 px-3 mt-5 mb-3 rounded-[4px]"
            >
                <h1 className="text-[16px] text-white font-grotesk tracking-[4px]">
                    MY WORK
                </h1>
            </Button>
            <h2 className="text-[40px] text-white font-grotesk font-bold leading-[48px] mb-10">
                RECENT PROJECT
            </h2>
            <div className="grid grid-cols-3 gap-x-8">
              {
                [1,2,3,4,5,6].map(()=>{
                    return (
                        <Card className="w-[378px] h-[350px] mb-10">
                            <Image src="/images/popup-project-1.jpg" width={328} height={246} className="mb-4 rounded-[8px]"/>
                            <div className="flex justify-between items-end pr-1">
                                <div>
                                    <h5 className="text-[20px] text-black font-grotesk font-semibold">Website Design</h5>
                                    <p className="text-[#707476] font-grotesk">Web Design, App Design</p>
                                </div>
                                <div className="w-[45px] h-[45px] bg-[#1877F2] rounded-[50%] border-2 border-black flex justify-center items-center">
                                    <a href="/" className="text-[20px]">
                                    <i className="fa fa-long-arrow-right text-white font-grotesk font-bold" />
                                    </a>
                                </div>
                            </div>
                        </Card>
                    )
                })
              }
            </div>
      </div>

      {/* Experience */}
      <div className="grid grid-cols-1 px-[8.6%] bg-[#05192E]">
            <div>
            <Button
                type="primary"
                className="items-center bg-[#063661] w-fit h-[29px] p-0 px-3 mt-5 mb-3 rounded-[4px]"
            >
                <h1 className="text-[16px] text-white font-grotesk tracking-[4px]">
                    EXPERIENCE
                </h1>
            </Button>
            <h2 className="text-[40px] text-white font-grotesk font-bold leading-[48px] mb-12">
                MY WORK <span className="text-[#0788FF]">EXPERIENCE</span>
            </h2>
            </div>
            {
                [1,2,3].map(()=>{
                    return (
                        <div className="grid grid-cols-12 px-2 py-6 bg-[#063660] rounded-[10px] mb-5">
              <div className="col-span-3">
                    <div className="ml-4 w-[250px] h-[200px] px-5 py-5 bg-[#0788FF] rounded-[8px]">
                        <h4 className="text-[24px] text-white font-grotesk font-bold leading-[28.8px] mb-2">
                            Front-end Developer
                        </h4>
                        <span className="text-[14px] text-white font-grotesk mb-2">
                            WELAB | REMOTE
                        </span>
                        <p className="text-[16px] text-white font-grotesk mb-4">
                            JAN 2019 - PRESENT
                        </p>
                        <button className="bg-white px-4 py-[2px] rounded-[40px]">
                            <span className="text-[12px] text-[#040c16] font-grotesk font-bold">FULL TIME</span>
                        </button>
                    </div>
              </div>
              <div className="col-span-9 px-4 ">
                <h5 className="text-[32px] text-white font-grotesk font-bold mb-1">
                    About Company
                </h5>
                <p className="text-[16px] text-white font-grotesk leading-[25.6px]">
                    Lorem ipsum dolor sit amet, consectetur
                    adipisicing elit, sed do eiusmod tempor
                    incididunt ut labore et dolore magna aliqua.
                    Ut enim ad minim veniam, quis nostrud exercitation
                    ullamco laboris nisi ut aliquip ex ea commodo
                    consequat. Duis aute irure dolor.Lorem ipsum 
                    dolor sit amet, consectetur adipisicing elit,
                    sed do eiusmod tempor incididunt ut labore et dolore
                    magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation .
                </p>
              </div>
        </div>
                    )
                })
            }
      </div>
    </>
  );
};

export default Homepage;
